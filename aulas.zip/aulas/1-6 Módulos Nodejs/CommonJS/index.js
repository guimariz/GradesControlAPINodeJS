const op = require("./operacoes.js");
const multiplicacao = require("./operacoes2.js");

console.log(op.soma(2, 3));
console.log(op.subtracao(5, 3));
console.log(op.nome);
console.log(multiplicacao(3, 4));