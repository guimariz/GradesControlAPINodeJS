import op from "./operacoes.js";
import multi from "./operacoes2.js";
import {divisao, resto} from "./operacoesNomeados.js";

console.log(op.soma(2, 3));
console.log(op.subtracao(5, 3));
console.log(op.nome);
console.log(multi(3, 4));
console.log(divisao(10, 2));
console.log(resto(7, 2));